package server;

import java.util.Date;
import java.util.List;

import javax.annotation.ManagedBean;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.jmx.export.annotation.ManagedResource;


@Entity
@Table(name = "tweets")
public class Tweet {

 
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long id;
  @NotNull
  private String user;
  @NotNull
  private String text;
  @NotNull
  private Date date;
  private boolean facebookid;
  private boolean tweeterid;
  private boolean llinkedinid;
  

  public Tweet() { }

  public Tweet(long id) { 
    this.id = id;
  }





public Tweet(String user,String text, Date date, boolean facebookid, boolean tweeterid, boolean llinkedinid) {
	this.text = text;
	this.user = user;
	this.date = date;
	this.facebookid = facebookid;
	this.tweeterid = tweeterid;
	this.llinkedinid = llinkedinid;
}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}

public String getUser() {
	return user;
}

public void setOwner(String user) {
	this.user = user;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}

public boolean isFacebookid() {
	return facebookid;
}

public void setFacebookid(boolean facebookid) {
	this.facebookid = facebookid;
}

public boolean isTweeterid() {
	return tweeterid;
}

public void setTweeterid(boolean tweeterid) {
	this.tweeterid = tweeterid;
}

public boolean isLlinkedinid() {
	return llinkedinid;
}

public void setLlinkedinid(boolean llinkedinid) {
	this.llinkedinid = llinkedinid;
}



  
  
  
} 