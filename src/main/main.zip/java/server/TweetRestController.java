package server;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TweetRestController {
	@Autowired
	private TweetDao tweetDao;
	  
	@RequestMapping(path="/tweets", method = RequestMethod.GET)
	public List<Tweet> getAll(){
		return (List<Tweet>) tweetDao.findAll();
	}
	
	

	
	@RequestMapping(path="/createTweet", method = RequestMethod.POST)
	  public String create(@RequestBody Tweet tweet) {
	    try {
	      tweetDao.save(tweet);
	    }
	    catch (Exception ex) {
	      return "Error creating the tweet: " + ex.toString();
	    }
	    return "tweet succesfully created! (id = " + tweet.getId() + ")";
	  }
	
	  @RequestMapping(path="/delete", method = RequestMethod.POST)
	  public String delete(@RequestParam long id) {
	    try {
	      User user = new User(id);
	      userDao.delete(user);
	    }
	    catch (Exception ex) {
	      return "Error deleting the user: " + ex.toString();
	    }
	    return "User succesfully deleted!";
	  }
	
	  @RequestMapping(path="/get-by-email", method = RequestMethod.GET)
	  public User getByEmail(@RequestParam String email) {
	    User user = null;
	    user = userDao.findByEmail(email);
	    
	    return user;
	  }
	  
	  @RequestMapping(path="/users/{username}", method = RequestMethod.GET)
	  public User getByName(@PathVariable("username") String username) {
	    User user = null;
	    try {
	      user = userDao.findByUsername(username);
	    }
	    catch (Exception ex) {
	      System.out.println(ex);
	    }
	    return user;
	  }
	  
	  @RequestMapping(path="/update", method = RequestMethod.POST)
	  public String updateUser(@RequestParam long id,@RequestParam  String email,@RequestParam String name) {
	    try {
	      User user = userDao.findOne(id);
	      user.setEmail(email);
	      user.setUsername(name);
	      userDao.save(user);
	    }
	    catch (Exception ex) {
	      return "Error updating the user: " + ex.toString();
	    }
	    return "User succesfully updated!";
	  }
} 