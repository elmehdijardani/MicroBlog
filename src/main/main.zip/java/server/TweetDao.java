package server;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Transactional
public interface TweetDao extends CrudRepository<Tweet, Long> {

  
  public Tweet findById(long id);
  public Tweet findByUser(String user);

} 