package webControllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import server.User;

@Controller
public class SignupController {
	@RequestMapping("/")
	@ResponseBody
	String emptypage(Model model){
//		RestTemplate restTemplate = new RestTemplate();
//        Map<String, String> params = new HashMap<>();
//        params.put("email", "wwww");
//        List<User> users = (List<User>) restTemplate.getForObject("http://localhost:8080/users", List.class);
//     
//				
//		model.addAttribute("users",users);
		return "enpty page";
	}
	
	@RequestMapping(value="signup", method=RequestMethod.GET)
	String addUser(){
		return "signup";
	}
	
	@RequestMapping(value="signup", method=RequestMethod.POST)
	String addUser(@RequestParam String username, @RequestParam String password, @RequestParam String email, @RequestParam String facebookid,
			@RequestParam String twitterid,@RequestParam String linkedinid, Model model){
		User user = new User(username, password, email, facebookid, twitterid, linkedinid);
			RestTemplate restTemplate = new RestTemplate();
	        
			try {
				restTemplate.postForObject("http://localhost:8080/createUser", user,User.class);
			} catch (HttpMessageNotReadableException e) {
				//e.printStackTrace();
			}
	     
			return "signup";
		
			
			
		
		
	}

}
