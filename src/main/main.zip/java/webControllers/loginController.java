package webControllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import server.User;

@Controller
public class loginController {
	RestTemplate restTemplate = new RestTemplate();

	@RequestMapping(value="login", method=RequestMethod.GET)
	String addUser(){
		return "login";
	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	String getUser(@RequestParam String username,@RequestParam String password, Model model){
		
		
        User user = new User();
        Map<String,String> params = new HashMap<>();
        params.put("username", username);
		try {
			user =  restTemplate.getForObject("http://localhost:8080/users/{username}", User.class, params);
		} catch (HttpMessageNotReadableException e) {
			//e.printStackTrace();
		}
		if( user!=null && user.getPassword().equals(password) ){
			model.addAttribute("user", user);
			return "home";
		}
		else{
			model.addAttribute("error", "authentification failed !");
			return "login";
		}
		
	}

}
