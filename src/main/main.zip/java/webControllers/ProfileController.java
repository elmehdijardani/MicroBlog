package webControllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import server.User;

@Controller
public class ProfileController {
	RestTemplate restTemplate = new RestTemplate();

	
	@RequestMapping(value="profile/{username}", method=RequestMethod.GET)
	String getUser(@PathVariable("username") String username, Model model){
		
		
        User user = null;
        Map<String,String> params = new HashMap<>();
        params.put("username", username);
		try {
			user =  restTemplate.getForObject("http://localhost:8080/users/{username}", User.class, params);
		} catch (HttpMessageNotReadableException e) {
			//e.printStackTrace();
		}
		
		model.addAttribute("user", user);
		return "profile";
	}
	
	@RequestMapping(value="profile", method=RequestMethod.GET)
	String showuser(){
        
		
		
		return "profile";
	}

}
